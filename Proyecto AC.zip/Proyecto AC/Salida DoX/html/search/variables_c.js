var searchData=
[
  ['statechangetime_0',['stateChangeTime',['../_documentacion_8cpp.html#a37bf49eb88579b3f6c33a4c0f1e78c57',1,'Documentacion.cpp']]]
];
