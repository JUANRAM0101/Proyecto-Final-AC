var searchData=
[
  ['photo_5fresistor_5fpin_0',['PHOTO_RESISTOR_PIN',['../_documentacion_8cpp.html#aa7ddd7d2bbb19975761492b648736b43',1,'Documentacion.cpp']]]
];
