var searchData=
[
  ['max_5fattempts_0',['MAX_ATTEMPTS',['../_documentacion_8cpp.html#acfbaea5c4bdf582b5f84f93780759290',1,'Documentacion.cpp']]]
];
