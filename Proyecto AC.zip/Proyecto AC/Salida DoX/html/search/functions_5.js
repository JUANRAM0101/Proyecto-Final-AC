var searchData=
[
  ['reset_0',['reset',['../_documentacion_8cpp.html#ad20897c5c8bd47f5d4005989bead0e55',1,'Documentacion.cpp']]]
];
