var searchData=
[
  ['hall_5fpin_0',['HALL_PIN',['../_documentacion_8cpp.html#acced00b621563665fb12c99f950a540f',1,'Documentacion.cpp']]]
];
