var searchData=
[
  ['lcd_0',['lcd',['../_documentacion_8cpp.html#ab605f245474d9c184947fcc008110bf8',1,'Documentacion.cpp']]],
  ['led_5fblue_5fpin_1',['LED_BLUE_PIN',['../_documentacion_8cpp.html#a284e10e9c3a1f9952ed165852d6b5d4d',1,'Documentacion.cpp']]],
  ['led_5fgreen_5fpin_2',['LED_GREEN_PIN',['../_documentacion_8cpp.html#aaa543d46c18cea1662cd130fdaa10e8d',1,'Documentacion.cpp']]],
  ['led_5fred_5fpin_3',['LED_RED_PIN',['../_documentacion_8cpp.html#a4b8bbf13fddebefa9974907ff08981a0',1,'Documentacion.cpp']]],
  ['loop_4',['loop',['../_documentacion_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'Documentacion.cpp']]]
];
