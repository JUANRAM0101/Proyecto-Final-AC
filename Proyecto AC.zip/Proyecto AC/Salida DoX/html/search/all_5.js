var searchData=
[
  ['getasterisks_0',['getAsterisks',['../_documentacion_8cpp.html#a4156e35267cef7cb1a1ce2cae94f2931',1,'Documentacion.cpp']]]
];
